package dbo;

import java.util.Date;

public class TrainTicket {
	private String ticketNumber;
	private String trainNumber;
	private TrainStation departureStation;
	private TrainStation arrivalStation;
	private Trip trip;
	private Passenger passenger;
	
	private boolean isReserved;
	private String seatNumber;
	private float reservationPrice;
	
	private Date departureDateTime;
	private Date arrivalDateTime;
	private long duration;
	
	public Date getDepartureDateTime() {
		return departureDateTime;
	}
	public void setDepartureDateTime(Date departureDateTime) {
		this.departureDateTime = departureDateTime;
	}
	public Date getArrivalDateTime() {
		return arrivalDateTime;
	}
	public void setArrivalDateTime(Date arrivalDateTime) {
		this.arrivalDateTime = arrivalDateTime;
	}
	public Passenger getPassenger() {
		return passenger;
	}
	public void setPassenger(Passenger passenger) {
		this.passenger = passenger;
	}
	private float price;
	
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public TrainStation getDepartureStation() {
		return departureStation;
	}
	public void setDepartureStation(TrainStation departureStation) {
		this.departureStation = departureStation;
	}
	public TrainStation getArrivalStation() {
		return arrivalStation;
	}
	public void setArrivalStation(TrainStation arrivalStation) {
		this.arrivalStation = arrivalStation;
	}
	public Trip getTrip() {
		return trip;
	}
	public void setTrip(Trip trip) {
		this.trip = trip;
	}
	public String getTicketNumber() {
		return ticketNumber;
	}
	public void setTicketNumber(String ticketNumber) {
		this.ticketNumber = ticketNumber;
	}
	public String getTrainNumber() {
		return trainNumber;
	}
	public void setTrainNumber(String trainNumber) {
		this.trainNumber = trainNumber;
	}
	public boolean isReserved() {
		return isReserved;
	}
	public void setReserved(boolean isReserved) {
		this.isReserved = isReserved;
	}
	public String getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}
	public float getReservationPrice() {
		return reservationPrice;
	}
	public void setReservationPrice(float reservationPrice) {
		this.reservationPrice = reservationPrice;
	}
	public long getDuration() {
		return duration;
	}
	public void setDuration(long duration) {
		this.duration = duration;
	}
	
}
