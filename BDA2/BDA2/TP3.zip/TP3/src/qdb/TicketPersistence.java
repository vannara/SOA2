package qdb;

import configuration.DbContext;
import dbo.City;
import dbo.Trip;

public class TicketPersistence {
private static DbContext context =DbContext.getInstance();
	
	public TicketPersistence(City from, City to, float distance){
		Trip travel=new Trip();
		travel.setFromCity(from);
		travel.setToCity(to);
		travel.setDistance(distance);
		
		context.db.store(travel);
		System.out.println("Stored " + travel);
	}
}
