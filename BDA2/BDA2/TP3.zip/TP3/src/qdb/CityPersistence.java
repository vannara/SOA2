package qdb;

import configuration.DbContext;
import dbo.City;

public class CityPersistence {
	
	private static DbContext context =DbContext.getInstance();

	public void createCity(String cityName) {
		
		City city = new City(cityName);
		context.db.store(city);
		System.out.println("Stored " + city);
	}
	
}
